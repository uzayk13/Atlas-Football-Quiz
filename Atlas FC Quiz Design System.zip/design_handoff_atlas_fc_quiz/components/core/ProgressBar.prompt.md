Thin pill progress bar tracking round N of the quiz.

```jsx
<ProgressBar value={3} max={10} />
```
