Small pill label — used mainly for player position codes on `PlayerCard`.

```jsx
<Badge>FW</Badge>
<Badge>GK</Badge>
<Badge tone="neutral">Round 3</Badge>
```

Recognizes `GK`/`DF`/`MF`/`FW` and auto-assigns a distinct color per position; any other text falls back to neutral gray.
