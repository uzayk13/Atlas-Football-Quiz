Chunky, pressable call-to-action button — the primary tappable surface across the quiz (Kick Off, Next Question, Play Again).

```jsx
<Button variant="primary" onClick={startGame}>Kick Off</Button>
<Button variant="gold" size="lg">Play Again</Button>
<Button variant="ghost">Skip</Button>
```

Variants: `primary` (pitch green, default), `gold` (trophy accent, use for celebratory CTAs like "Play Again"), `ghost` (outline, low-emphasis secondary action). Sizes: `md` (default), `lg`. Has hover-lift and a physical press-down animation (solid bottom shadow collapses on `:active`) — don't wrap it in extra shadow/elevation.
