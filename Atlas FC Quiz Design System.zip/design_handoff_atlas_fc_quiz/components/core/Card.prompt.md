Generic resting surface — white card, soft ambient shadow, rounded corners, thin border. Use for any grouped content that isn't a tappable button (e.g. results summary, settings row).

```jsx
<Card>
  <h3>Final score</h3>
  <p>8 / 10</p>
</Card>
```

Set `padded={false}` when the child needs to control its own padding (e.g. an edge-to-edge image).
