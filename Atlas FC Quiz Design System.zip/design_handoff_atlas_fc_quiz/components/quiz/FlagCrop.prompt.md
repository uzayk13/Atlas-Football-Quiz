Round zoomed crop of a real flag SVG, used to show an emblem (coat of arms, sun, star) at draggable-chip size without ever hand-drawing one. `crop.fx`/`crop.fy` mark the emblem's center as a 0..1 fraction of the source flag's own box.

```jsx
<FlagCrop code="pt" crop={{ fx: 0.4, fy: 0.5 }} size={44} />
<FlagCrop code="ar" crop={{ fx: 0.5, fy: 0.5 }} size={64} />
```

Used inside `FlagColorCanvas`'s drag chips/placed markers, and standalone anywhere a flag's real emblem needs calling out.
