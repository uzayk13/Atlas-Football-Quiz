Hand-color-the-flag exercise — pick a palette color, tap a region to fill it, drag any real emblem crops (coat of arms, sun, star) into place. Self-manages fill/placement state; reports progress upward so the host screen can gate its own Submit button and score banner.

```jsx
<FlagColorCanvas
  code="pt"
  palette={["#046A38", "#DA291C"]}
  regions={[
    { id: "left", shape: "rect", x: 0, y: 0, w: 120, h: 200, correctColor: "#046A38" },
    { id: "right", shape: "rect", x: 120, y: 0, w: 180, h: 200, correctColor: "#DA291C" },
  ]}
  symbols={[{ id: "arms", label: "Coat of arms", target: { x: 120, y: 100 }, size: 44, crop: { fx: 0.4, fy: 0.5 } }]}
  submitted={submitted}
  onProgress={(score, total, canSubmit) => setState({ score, total, canSubmit })}
/>
```

Give it a fresh `key` per player/flag so its internal fill state resets. Regions/symbols are plotted on a fixed 300×200 viewBox — draw the flag's real proportions and only the colors/shapes that actually vary. Once `submitted`, region strokes turn success/danger green/red instead of the neutral outline.
