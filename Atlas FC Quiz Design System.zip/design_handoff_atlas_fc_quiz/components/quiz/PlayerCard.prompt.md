The featured-player card shown on a question — currently a flat silhouette placeholder since no real player photos were supplied.

```jsx
<PlayerCard position="FW" />
<PlayerCard name="Reveal after answer" club="Al Nassr" position="FW" nationalityCode="pt" />
```

Swap the silhouette `<div>` for a real `<img>` once photos are available.
