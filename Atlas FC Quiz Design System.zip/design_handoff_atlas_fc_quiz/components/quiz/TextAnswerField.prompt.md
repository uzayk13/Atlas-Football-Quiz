Free-text answer input for "type it yourself" quiz rounds (nationality, club, full name, position) — the harder alternative to four-choice `AnswerTile`. Do the loose match (case/accent/punctuation-insensitive) yourself before setting `state`.

```jsx
<TextAnswerField label="Club" value={club} onChange={setClub} />
<TextAnswerField label="Nationality" value="Brasil" state="correct" />
<TextAnswerField label="Full name" value="Neymar" state="wrong" correctAnswer="Neymar da Silva Santos Júnior" />
```

Border/background flips to the success or danger pair once `state` is set; input stays enabled until the caller disables it post-submit.
