Gold pill showing the live/final score, scoreboard-style.

```jsx
<ScoreBadge score={8} total={10} />
<ScoreBadge score={8} total={10} size="lg" />
```
