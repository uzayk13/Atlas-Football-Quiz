# Handoff: Atlas FC Quiz

## Overview
Atlas FC Quiz is a single-player, mobile-first football-trivia game. Each round shows a player: the user types four free-text answers (nationality, club, full name, position), then hand-colors that player's national flag by tapping palette swatches onto flag regions and dragging any real emblem (coat of arms, sun, star) into place. Score accumulates across all rounds to a final results screen.

## About the Design Files
The files in this bundle are **design references built in HTML/React** — they show the intended look, copy, and interaction behavior. They are not production code to import as-is. The task is to **recreate this design in the target app's actual codebase** (its real framework — React Native, SwiftUI, Kotlin/Compose, etc. — and its existing state-management/navigation patterns), using this bundle as the source of truth for visuals and behavior. If the target codebase has no existing framework yet, pick whatever's most appropriate and implement there.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, shadows, and copy here are final — recreate them pixel-for-pixel, don't restyle.

## Screens / Views

### 1. Home
- Dark "stadium at night" background (`--navy-900`).
- Centered column: small caps wordmark "ATLAS FC" (`700 20px/1 var(--font-body)`, letter-spacing `0.3em`, color `--gold-400`), then "QUIZ" in display type (`--text-display-xl`, color `--cream-050`), then one line of body copy (`--text-body-md`, `--gray-300`, max-width 280–320px): "Type each answer — nationality, club, full name, position — then color in the flag by hand."
- One CTA button, gold variant, size lg, label "⚽ Kick Off".
- File: `ui_kits/quiz-app/HomeScreen.jsx`.

### 2. Fields round (per player)
- Top: caption "PLAYER {n}/{total}" (label-caps style, `--color-text-muted`) next to a `ProgressBar` (value = round, max = total players).
- Centered `PlayerCard` — a flat circular silhouette placeholder (no real photos), then the player's first name only, in `--text-display-sm`.
- Four stacked `TextAnswerField`s, one per field: Nationality, Club, Full name, Position. Each is a label (label-caps, muted) + a 52px-tall text input (2px border, `--radius-md`, `--text-body-md` bold).
- Answer matching is case/accent/punctuation-insensitive (e.g. "brasil" ≈ "Brazil"). A "match strictness" toggle (loose/exact) exists as a designer tweak — default is loose.
- "Submit" button (primary, lg, full width) is disabled until all 4 fields are non-empty. On submit: fields lock, each flips to a green "correct" or red "wrong" style (background/border/text recolor to the success or danger token pair), and wrong fields show "Correct answer: {answer}" underneath in `--red-600`.
- A score banner appears after submit: dark navy pill row, "Score so far" in cream text, `ScoreBadge` (gold pill, score/total) on the right.
- Button becomes gold "Next" → advances to the Flag round for the same player.
- File: `ui_kits/quiz-app/FieldsScreen.jsx`.

### 3. Flag round (per player)
- Same progress header, suffixed "· FLAG".
- Headline "Color in {firstName}'s flag" + one line of muted instructions.
- The flag canvas: a 300×200 SVG made of a few flat color regions (rects/circles/polygons matching that flag's real geometry) plus, for some flags, one draggable "emblem" chip (a real zoomed crop of the flag's own SVG artwork — never a redrawn icon).
- A palette of that flag's real colors sits beside the canvas as tappable circular swatches (40px, pill border, active swatch gets a colored ring). Tapping a swatch selects the fill color; tapping a region fills it.
- Any emblem starts as a chip under "Drag onto flag" with a dashed circular drop target on the canvas at its correct spot; dropping it there places a real cropped zoom of the flag's own emblem.
- "Check Flag" (disabled until every region is filled and every emblem placed) reveals correctness: each region's outline turns green/red (success/danger border tokens, 4px) depending on whether its fill matches the real color.
- After checking: score banner (same navy/gold pattern as Fields), plus a small "The real flag" caption next to the actual flag SVG at 100×67 for comparison.
- Button becomes gold "Next Player" (or "See Final Score" on the last player).
- File: `ui_kits/quiz-app/FlagScreen.jsx`.

### 4. Results
- Same dark stadium background as Home.
- "FULL TIME 🏆" (great score, ≥70%) or "FULL TIME" (display-lg, cream), large `ScoreBadge` (size lg) showing total score / grand total (fields + flag points across all players), one line of encouragement copy, gold "Play Again" CTA.
- File: `ui_kits/quiz-app/ResultsScreen.jsx`.

## Interactions & Behavior
- No timers — this is an untimed, single-player, tap-through game.
- Transitions are simple state swaps (no page-level animation currently implemented beyond token-level bounce/shake easings defined for future use — see `--ease-bounce`/`--ease-out` in tokens).
- Text input has no autocomplete/fuzzy suggestions — it's a strict-but-forgiving string match (normalizes case, accents, punctuation).
- Flag drag-and-drop uses native HTML5 drag events; on touch platforms recreate with the platform's drag/gesture primitives, not literal `draggable` attributes.
- Sample data (5 players with hand-plotted flag geometry) lives in `ui_kits/quiz-app/data.js` — treat this as placeholder content, not final data.

## State Management
- `stage`: `"home" | "fields" | "flag" | "results"`.
- `round`: current player index.
- `totalScore`: running sum across all rounds.
- Per-Fields-round: a dict of typed values per field key, `submitted` boolean, derived per-field correctness and round score.
- Per-Flag-round: a dict of region→fill-color, a dict of symbol-id→placed boolean, currently-selected palette color, `submitted` boolean, derived score/total/canSubmit.

## Design Tokens
Full token files are included under `tokens/` — copy exact values, don't approximate:
- **Colors** (`tokens/colors.css`): brand primary `--color-brand-primary` (`#1c7a44`, pitch green), gold accent `--color-accent-gold` (`#e0a812`), success (`#229b54`/bg `#e3f7ea`/border `#3dbb70`), danger (`#d93a40`/bg `#fbe3e4`/border `#ef5a5f`), navy dark surfaces (`#0a1626`…`#223c60`), warm cream neutrals (`#faf8f2`, `#f3efe3`, `#e9e2cf`), warm grays for text.
- **Typography** (`tokens/typography.css`): display face **Boogaloo** (headlines/scores/buttons only), body face **Inter** (everything else) — never mixed. Sizes from `--text-display-xl` (700 64px) down to `--text-label-caps` (700 12px, 0.08em tracking, used for all-caps captions).
- **Spacing/radius/shadow/motion** (`tokens/spacing.css`): 4px base scale, `--radius-md` 14px (buttons/inputs), `--radius-lg` 20px (cards), `--radius-pill` for chips/badges; ambient shadows (`--shadow-sm/md/lg`) for resting cards, a separate solid "button shadow" (`--shadow-button`, 3px offset) for the pressable-button pattern; `--ease-bounce`/`--ease-out` easings.

## Assets
- **Fonts**: `assets/fonts/Inter-Regular.woff2` (self-hosted). Boogaloo is currently loaded from Google Fonts' CDN because the uploaded `Boogaloo-Regular.woff2` file is corrupt — get a valid Boogaloo file for a fully self-hosted build.
- **Flags**: `assets/flags/` — real SVGs from the open-source flag-icons set, 4:3 ratio, used directly (never redrawn). Only 5 are included in this bundle (ar, be, br, fr, pt) since only those 5 have hand-plotted flag-coloring geometry defined in `data.js`; the full design system has 36 flags if more players/nationalities get added later.

## Files
Source files below are saved as `.jsx.txt` (not `.jsx`) so they read as plain text — rename back to `.jsx` if you want to run them.
```
ui_kits/quiz-app/        HomeScreen.jsx, FieldsScreen.jsx, FlagScreen.jsx, ResultsScreen.jsx,
                          data.js (sample players + grading helpers), index.html (wired demo),
                          tweaks-panel.jsx (designer-only tweak controls, not part of the product)
components/quiz/         TextAnswerField, FlagCrop, FlagColorCanvas, PlayerCard, ScoreBadge
                          (.jsx = implementation, .d.ts = prop types, .prompt.md = usage notes)
components/core/         Button, Badge, Card, ProgressBar
tokens/                  colors.css, typography.css, spacing.css
styles.css               imports all tokens — the single stylesheet entry point
assets/fonts/, assets/flags/
design-system-readme.md  full design-system voice/visual guidelines (brand rationale, do's/don'ts)
```

Open `ui_kits/quiz-app/index.html` in a browser to see the whole flow live before implementing.
