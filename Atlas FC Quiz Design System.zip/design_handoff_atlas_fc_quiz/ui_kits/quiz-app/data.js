// Sample quiz data — one round per player: type-in fields, then color their flag.
// Flag regions/symbols are hand-plotted on a 300x200 viewBox against the real SVGs in
// assets/flags/ — only 5 players have geometry defined for now.
window.FIELDS = [
  { key: "nationality", label: "Nationality" },
  { key: "club", label: "Club" },
  { key: "fullName", label: "Full name" },
  { key: "position", label: "Position" },
];

window.PLAYERS = [
  {
    name: "Neymar Jr.",
    firstName: "Neymar",
    code: "br",
    answers: { nationality: "Brazil", club: "Al-Hilal", fullName: "Neymar da Silva Santos Júnior", position: "FW" },
    flag: {
      regions: [
        { id: "bg", shape: "rect", x: 0, y: 0, w: 300, h: 200, correctColor: "#009739" },
        { id: "diamond", shape: "polygon", points: "150,18 282,100 150,182 18,100", correctColor: "#FEDD00" },
        { id: "circle", shape: "circle", cx: 150, cy: 100, r: 42, correctColor: "#002776" },
      ],
      palette: ["#009739", "#FEDD00", "#002776"],
      symbols: [],
    },
  },
  {
    name: "Kylian Mbappé",
    firstName: "Kylian",
    code: "fr",
    answers: { nationality: "France", club: "Real Madrid", fullName: "Kylian Mbappé Lottin", position: "FW" },
    flag: {
      regions: [
        { id: "left", shape: "rect", x: 0, y: 0, w: 100, h: 200, correctColor: "#0055A4" },
        { id: "mid", shape: "rect", x: 100, y: 0, w: 100, h: 200, correctColor: "#FFFFFF" },
        { id: "right", shape: "rect", x: 200, y: 0, w: 100, h: 200, correctColor: "#EF4135" },
      ],
      palette: ["#0055A4", "#FFFFFF", "#EF4135"],
      symbols: [],
    },
  },
  {
    name: "Cristiano Ronaldo",
    firstName: "Cristiano",
    code: "pt",
    answers: { nationality: "Portugal", club: "Al-Nassr", fullName: "Cristiano Ronaldo dos Santos Aveiro", position: "FW" },
    flag: {
      regions: [
        { id: "left", shape: "rect", x: 0, y: 0, w: 120, h: 200, correctColor: "#046A38" },
        { id: "right", shape: "rect", x: 120, y: 0, w: 180, h: 200, correctColor: "#DA291C" },
      ],
      palette: ["#046A38", "#DA291C"],
      symbols: [{ id: "arms", label: "Coat of arms", target: { x: 120, y: 100 }, size: 44, crop: { fx: 0.4, fy: 0.5 } }],
    },
  },
  {
    name: "Kevin De Bruyne",
    firstName: "Kevin",
    code: "be",
    answers: { nationality: "Belgium", club: "Manchester City", fullName: "Kevin De Bruyne", position: "MF" },
    flag: {
      regions: [
        { id: "left", shape: "rect", x: 0, y: 0, w: 100, h: 200, correctColor: "#000000" },
        { id: "mid", shape: "rect", x: 100, y: 0, w: 100, h: 200, correctColor: "#FDDA24" },
        { id: "right", shape: "rect", x: 200, y: 0, w: 100, h: 200, correctColor: "#EF3340" },
      ],
      palette: ["#000000", "#FDDA24", "#EF3340"],
      symbols: [],
    },
  },
  {
    name: "Lionel Messi",
    firstName: "Lionel",
    code: "ar",
    answers: { nationality: "Argentina", club: "Inter Miami", fullName: "Lionel Andrés Messi Cuccittini", position: "FW" },
    flag: {
      regions: [
        { id: "top", shape: "rect", x: 0, y: 0, w: 300, h: 67, correctColor: "#74ACDF" },
        { id: "mid", shape: "rect", x: 0, y: 67, w: 300, h: 66, correctColor: "#FFFFFF" },
        { id: "bottom", shape: "rect", x: 0, y: 133, w: 300, h: 67, correctColor: "#74ACDF" },
      ],
      palette: ["#74ACDF", "#FFFFFF"],
      symbols: [{ id: "sun", label: "Sun of May", target: { x: 150, y: 100 }, size: 46, crop: { fx: 0.5, fy: 0.5 } }],
    },
  },
];

// Loose text-answer matching: case/accent/punctuation-insensitive.
window.normalizeAnswer = function normalize(s) {
  return (s || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
};
window.isAnswerCorrect = function isCorrect(input, answer) {
  if (window.MATCH_STRICTNESS === "exact") {
    return (input || "").trim() === (answer || "").trim();
  }
  return window.normalizeAnswer(input) === window.normalizeAnswer(answer);
};

window.flagTotal = function flagTotal(flag) {
  return flag.regions.length + flag.symbols.length;
};
window.GRAND_TOTAL = window.PLAYERS.reduce(
  (sum, p) => sum + window.FIELDS.length + window.flagTotal(p.flag),
  0
);
