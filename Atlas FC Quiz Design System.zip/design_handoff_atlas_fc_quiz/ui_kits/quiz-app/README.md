# Atlas FC Quiz — UI Kit

The single product surface: a mobile, single-player trivia game about footballers. Each player round has two parts: type the answers yourself, then color in their flag by hand.

## Files
- `index.html` — wired, interactive app (Home → [Fields → Flag] × 5 players → Results → replay).
- `data.js` — sample player set (`window.PLAYERS`) with per-player field answers and flag region/symbol geometry, plus the loose-match helpers screens use to grade text input.
- `HomeScreen.jsx` — title + Kick Off CTA, dark stadium background.
- `FieldsScreen.jsx` — round progress, silhouette `PlayerCard`, four `TextAnswerField`s (nationality/club/full name/position), score banner + Next.
- `FlagScreen.jsx` — round progress, `FlagColorCanvas` (palette-fill + drag-drop emblem), score banner, real-flag reveal, Check Flag / Next Player.
- `ResultsScreen.jsx` — final score (`ScoreBadge`) out of the grand total, Play Again.

All screens compose primitives from `components/core/` and `components/quiz/` — no UI is re-implemented here. There's no multiple-choice mode anymore; guessing is free-text plus hand-coloring, which is harder and better matches "how well do you actually know this player."
