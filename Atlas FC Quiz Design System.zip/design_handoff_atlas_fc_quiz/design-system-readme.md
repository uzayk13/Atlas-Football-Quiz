
# Atlas FC Quiz — Design System

A quiz game brand for a personal project: **Atlas FC Quiz** tests how well you know footballers — their nationality, club, position, and flag. Built for one player (the user's brother) to guess-and-learn about players in a fast, arcade-y, "sports trivia night" way.

There is no existing codebase, Figma file, or brand guide for Atlas FC Quiz — this design system was authored from scratch from two inputs the user provided:
- `uploads/Boogaloo-Regular.woff2` + `uploads/Inter-Regular.woff2` — the two typefaces to use (display + body).
- 36 country flag SVGs (`uploads/*.svg`, from the open-source `flag-icons` set — Argentina, Belgium, Brazil, Canada, Switzerland, Cameroon, Colombia, Germany, Denmark, Ecuador, Egypt, Spain, France, England, Great Britain, Georgia, Ghana, Croatia, Hungary, Italy, Japan, South Korea, Morocco, Nigeria, Netherlands, Norway, Poland, Portugal, Serbia, Sweden, Slovenia, Turkey, USA, Uruguay, Kosovo) — these are the nationalities the quiz asks about.

No logo was supplied. **No logo has been invented.** Wherever a mark would sit, the wordmark "Atlas FC Quiz" is set in Boogaloo instead. See ICONOGRAPHY below.

## Product
One product: the **Atlas FC Quiz app** — a single-player, mobile-first trivia game. Round structure: a player's photo/silhouette placeholder + one trivia question (nationality / club / position / "guess the flag"), four multiple-choice answers, immediate right/wrong feedback, then a running score. See `ui_kits/quiz-app/`.

---

## Content fundamentals

**Voice:** hype-man sports commentator, not a form or a dashboard. Short, punchy, exclamatory. Talks *to* the player directly ("you") and roots for them like a coach or an announcer.

- Correct answer: **"GOAL!"** / **"Nice one!"** / **"You know your football!"**
- Wrong answer: **"Offside!"** / **"So close!"** / **"Next one's yours."** — never harsh, always a quick recovery line that pushes to the next question.
- Prompts are phrased as a dare or a callout, not a neutral instruction: *"Guess the shirt."*, *"Whose flag is this?"*, *"Name the club."*
- Buttons are verbs, not nouns: **"Kick Off"**, **"Next Question"**, **"Play Again"** — never "Submit" or "Continue".
- Numbers are treated like a live scoreboard, not a statistic: **"3 in a row 🔥"**-style streak callouts (see emoji note below), final score framed as a match result, e.g. **"You scored 8 / 10"**.

**Casing:** Sentence case for body copy and buttons. Display headlines (Boogaloo) can go Title Case or ALL CAPS for maximum arcade energy ("FULL TIME", "MATCH DAY"). Never use all-lowercase stylized copy.

**Person:** second person ("you") throughout — the whole app talks directly to the player, coach-to-player, never third person or corporate "users."

**Emoji:** used sparingly, only as a scoreboard/energy accent (⚽ 🔥 🏆 🟥🟨), never inside body sentences and never as a bullet/icon replacement for real iconography (flags are always real SVGs, not emoji flags).

**Vibe:** matchday energy — a five-minute game your brother opens between other things. Confident, fast, a little cocky, always rooting for the player. Not academic, not corporate, not twee.

---

## Visual foundations

**Color:** pitch green is the brand primary (`--color-brand-primary`, `--green-600` `#1c7a44`) — used on primary buttons, headers, and progress. A warm trophy gold (`--color-accent-gold`, `#e0a812`) is the secondary accent, reserved for scores, streaks, and highlights — never used as a second primary. Feedback is unambiguous: green for correct (`--color-success`), red for wrong (`--color-danger`) — both paired with a light tinted background (`--color-success-bg` / `--color-danger-bg`) so a whole answer tile can flash color without becoming illegible. Neutrals are warm cream/off-white (`--cream-050` background, not stark white) with a warm dark navy (`--navy-900`) reserved for the app's dark "stadium at night" surfaces (score screens, headers). No purple, no cool-gray corporate neutrals.

**Type:** Boogaloo (a bouncy, rounded, comic-poster display face) is used for ALL headlines, scores, and button labels — anywhere the game should feel loud and fun. Inter carries all body copy, questions, and answer text, where legibility matters more than personality. Never mix — body text is never set in Boogaloo, headlines are never set in Inter. See `guidelines/type-*.html` cards.

**Spacing:** 4px base scale (`--space-1` … `--space-20`), generous touch targets — answer tiles are full-width and tall (min 56px) since this is a fast-tap mobile game, not a dense dashboard.

**Backgrounds:** flat color, no photography, no gradients, no textures/patterns. The "pitch" is suggested through color and chunky shapes, not literal grass illustration. Score/results screens use a solid navy "stadium lights off" background for contrast against gold score numbers.

**Animation:** playful and bouncy, matching Boogaloo's character — `--ease-bounce` (an overshoot cubic-bezier) on answer-tile taps and score pop-ins; `--ease-out` for simple fades/slides (question transitions, progress bar fill). Nothing spins or loops indefinitely. Correct answers get a quick scale-bounce "pop"; wrong answers get a short shake.

**Hover states (desktop/trackpad testing only — this is primarily a touch game):** buttons darken one step (`--color-brand-primary-hover`) and lift slightly (`translateY(-1px)`).

**Press states:** buttons use a "chunky button" pattern — a solid bottom shadow (`--shadow-button`, offset 3px, same hue one shade darker) that the button appears to press flat into on `:active` (`translateY(3px)` + shadow removed). This reads as physically pressable, arcade-cabinet-button style, not a flat material-design ripple.

**Borders:** thin (1px) neutral borders (`--color-border`) for resting cards/tiles; on interactive tiles the border thickens to 2px and takes the state color (green/red/gold) rather than adding a glow.

**Shadows:** soft, low-opacity ambient shadows (`--shadow-sm/md/lg`) for elevation (cards floating on the cream background) PLUS the separate solid-color "button shadow" described above for tappable elements — the two systems are deliberately different so buttons read as pressable and cards read as resting.

**Corner radii:** generous and consistent with the bouncy brand — `--radius-md` (14px) for buttons/answer tiles, `--radius-lg` (20px) for cards/panels, `--radius-pill` for score chips and flag pills. Nothing sharp-cornered.

**Cards:** white surface on the cream app background, `--radius-lg`, `--shadow-md`, 1px `--color-border`. No colored left-border accent strip.

**Transparency/blur:** minimal — only a subtle scrim (rgba navy at low opacity) behind modals/results overlays. No frosted-glass panels.

**Imagery:** no photography is included in this system (no footballer photos were supplied). Player "cards" use a flat silhouette placeholder tinted in brand colors rather than a stock photo, clearly marked as a placeholder for the user's own player photos.

---

## Iconography

No icon font or SVG icon set was supplied, and none is invented for generic UI glyphs (back arrows, close buttons, etc. are drawn with minimal inline SVG strokes matching the button's own color — treated as typography, not as an illustrated icon system).

**Flags are the one real, "branded" icon system in this app** — the 36 SVGs in `assets/flags/` (from the open-source flag-icons project, 4:3 ratio, no wrapping/border applied by the source) are the nationality answer format and are used directly, at consistent sizing, never redrawn or approximated. A quiz round's "guess the flag" mode and every nationality answer tile use these files verbatim via `<img>`/`<FlagChip>`.

Position badges (GK / DF / MF / FW) are short text labels in a pill, not icons — see `Badge`.

Emoji are used only as described in Content Fundamentals (⚽ 🔥 🏆), never as a substitute for the flag SVGs or for functional UI icons.

---

## Index

- `styles.css` — root stylesheet; imports everything under `tokens/`.
- `tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css` — design tokens.
- `assets/fonts/` — Boogaloo-Regular.woff2, Inter-Regular.woff2.
- `assets/flags/` — 36 nationality flag SVGs (flag-icons set).
- `guidelines/` — foundation specimen cards (Type, Colors, Spacing, Brand) shown in the Design System tab.
- `components/core/` — Button, Badge, Card, ProgressBar.
- `components/quiz/` — Components: PlayerCard, ScoreBadge, TextAnswerField, FlagCrop, FlagColorCanvas.
- `ui_kits/quiz-app/` — the Atlas FC Quiz app: Home, type-the-answer player round, color-the-flag round, Results screens, wired together in `index.html`.
- `SKILL.md` — portable Agent Skill version of this design system.

### Intentional additions
No source defined a component inventory (brand-new product, no codebase/Figma), so the standard set below was authored sized to what a quiz game actually needs — no Toast/Tabs/Dialog/Switch/etc. were added since the app has no use for them yet.

## Caveats / open questions for the user
- **No footballer photos supplied** — `PlayerCard` uses a flat silhouette placeholder. Send real (licensed) player photos if you want them swapped in.
- **No logo supplied** — wordmark-only for now, per policy on not inventing brand marks.
- **Uploaded Boogaloo-Regular.woff2 is corrupt** (~1.6KB, fails to decode) — `tokens/typography.css` temporarily loads Boogaloo from Google Fonts' CDN instead so headlines still render correctly. Re-upload a valid Boogaloo-Regular.woff2 to go fully self-hosted.
- Colors, the "chunky pressable button" style, and the bounce animation are original choices (no brand guide existed to source them from) — flag them if they don't match your brother's taste and we can re-explore.
